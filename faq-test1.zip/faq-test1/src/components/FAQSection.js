import React from "react";

function FAQSection({ data }) {
  return (
    <div>
      {data.map((faq, index) => (
        <div key={index} style={styles.item}>
          <p style={styles.question}>Q: {faq.question}</p>
          <p style={styles.answer}>A: {faq.answer}</p>
        </div>
      ))}
    </div>
  );
}

const styles = {
  item: {
    marginBottom: "15px",
    padding: "10px",
    border: "1px solid #ddd",
    borderRadius: "8px",
  },
  question: {
    fontWeight: "bold",
    marginBottom: "5px",
  },
  answer: {
    marginLeft: "10px",
  },
};

export default FAQSection;
