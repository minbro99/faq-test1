import React from "react";
import styled from "styled-components";

function SearchBar({ searchTerm, setSearchTerm }) {
  return (
    <SearchContainer>
      <SearchInput
        type="text"
        placeholder="검색어를 입력하세요..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
    </SearchContainer>
  );
}

export default SearchBar;

/* ✅ 반응형 스타일 적용 */
const SearchContainer = styled.div`
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
  width: 100%;
`;

const SearchInput = styled.input`
  width: 100%;
  max-width: 800px; /* 📌 질문과 답변(FAQ)과 같은 크기로 조정 */
  padding: 12px;
  font-size: 20px;
  border: 2px solid #ccc;
  border-radius: 10px;
  outline: none;

  @media (max-width: 768px) {
    font-size: 15px;
    padding: 10px;
  }

  @media (max-width: 480px) {
    font-size: 14px;
    padding: 8px;
  }
`;
