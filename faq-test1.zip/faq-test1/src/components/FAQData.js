// components/FAQData.js
import KakaoImage from "../styles/image.png";

const styles = {
  table: {
    width: "100%",
    borderCollapse: "collapse",
    marginTop: "20px",
    textAlign: "center",
  },
  th: {
    backgroundColor: "#33ff5b",
    border: "1px solid #ddd",
    padding: "10px",
    color: "#283747",
  },
  td: {
    // backgroundColor: "#2e86c1",
    border: "1px solid #ddd",
    padding: "10px",
    // color: "#ecf0f1",
  },
  ul: {
    listStyleType: "none", // 기본 점 제거
    padding: "0", // 패딩 제거
  },
  li: {
    fontSize: "16px",
    textAlign: "center", // 리스트도 중앙 정렬
    marginBottom: "5px", // 리스트 간격 조정
  },
  answerContainer: {
    display: "flex",
    flexDirection: "column", // 세로 정렬
    alignItems: "center", // 중앙 정렬
    textAlign: "center", // 텍스트 중앙 정렬
  },
  text: {
    fontSize: "15px",
    marginBottom: "20px", // 텍스트 간격 조정
  },
  image: {
    width: "400px", // 이미지 크기 조정
    height: "auto",
    marginBottom: "20px", // 이미지와 텍스트 간격
    borderRadius: "20px", // 둥근 모서리 적용 (선택 사항)
  },

};


const faqData = [
  // 기본 개념 및 정의
  {
    question: "❓DR이란 무엇인가요?",
    answer: <p>DR은 사람들이 사용하는 전기를 아낄 수 있도록 도와주는 프로그램이에요.<br /> 
    전기를 많이 쓰는 시간대에 전기를 줄이면 보상도 받을 수 있어요!💰</p>,
    category: "basic",
  },
  {
    question: "⁉️그렇다면 DR을 왜 해야할까요?",
    answer: <p>국민DR 사업은 전력 사용이 많은 시간대에 국민들이 전력 소비를 줄이면 보상을 받는 제도입니다! 💰<br />
    이를 통해 전력 공급 안정, 비용 절감, 친환경적인 에너지 운영이 가능해! 발전소 추가 가동 없이 전력 수급을 조절하고⚡,<br /> 국민도 전력 절약에 참여하면서 혜택을 받을 수 있어요 😊</p>,
    category: "basic",
  },
  {
    question: "⚙️그럼 DR은 누가 운영하고 관리하나요?",
    answer: <p>국민DR 사업은 **전력거래소(KPX)**가 전반적인 운영을 담당하고,<br /> 
    **수요관리사업자(누리플렉스)**가 참여 고객을 모집하고 관리해요!<br /> 
    전력 감축 요청 및 정산도 전력거래소에서 진행해요⚡😊</p>,
    category: "basic",
  },
  {
    question: "📝DR을 종류에 따라 분류를 보고싶어요!",
    answer: (
      <div>
        <p style={{fontSize:"20px", fontWeight:"bold"}}>DR은 참여대상, 운영주체, 주요목표 등의 기준으로 다음과 같이 분류할 수 있어요!🗃️</p>
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>구분</th>
              <th style={styles.th}>국민DR</th>
              <th style={styles.th}>주민DR</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={styles.td}>참여대상</td>
              <td style={styles.td}>대한민국 국민</td>
              <td style={styles.td}>지역 공동체(ex: 아파트, 상가 등)</td>
            </tr>
            <tr>
              <td style={styles.td}>운영주체</td>
              <td style={styles.td}>정부 & KPX(전력거래소)</td>
              <td style={styles.td}>지방자치단체 & 지역별 운영자</td>
            </tr>
            <tr>
              <td style={styles.td}>주요목표</td>
              <td style={styles.td}>전력 수급의 안정</td>
              <td style={styles.td}>지역의 전력 효율화</td>
            </tr>
          </tbody>
        </table>
      </div>
    ),
    category: "basic",
  },
  // 참여 및 등록
  {
    question: "👨‍👩‍👧‍👦DR에 참여하려면 어떻게 하면 되나요?",
    answer: (
      <p>
        절대로 어렵지 않아요!🙅🏼‍♂️ <br />
        단지 내 게시판이나 입주자 카페에 공지된 QR 코드나 링크를 통해 신청할 수 있습니다.🖊️ <br />
        관리사무소에서도 신청 가능합니다. ✒️<br />
        DR 이벤트는 특정 시간에 전력 사용을 줄이도록 요청받는 형태로 진행됩니다.
      </p>
    ),
    category: "register",
  },
  {
    question: "🏢저희 아파트는 무조건 신청이 가능한가요?",
    answer: <p>아니요!<br />
                모든 아파트및 공동체가 무조건 참여를 할 수 있는것은 아니에요!🙅🏼‍♂️<br />
                아파트에 스마트 전기 계량기가 설치된 공동체의 경우에만 참여가 가능합니다.🙌🏼</p>,
    category: "register",
  },
  {
    question: "💰혹시 DR에 참여하려면 따로 금액을 지불해야하는건 아니겠죠?",
    answer: <p>물론입니다!🙆🏼<br />
               참여를 위해 따로 돈이 들지 않아요.🤑<br />
               오히려 전기를 줄이면 보상을 받을 수 있어요!💰</p>,
    category: "register",
  },
  {
    question: "🛒제가 욕심이 많아서 여러DR을 참여하고 싶은데 가능할까요?",
    answer: <p>물론입니다!🙆🏼<br />
    다른 에너지 절감 프로그램 참여를 진행하면서, <br /> 
    동시에 다른 에너지 절감 프로그램도 참여를 하고 싶다면 중복 참여가 가능합니다.🙆🏼<br />
    ✳️예시:서울시 A아파트에 사는 김누리씨 → 국민DR을 진행하면서, 동시에 서울시에 운영하는 주민DR을 함께 참여가 가능합니다.👌🏼</p>,
    category: "register",
  },
  {
    question: "▶️오늘 신청을 하면 오늘부터 참여가 가능한가요?",
    answer: <p>아니요!🙅🏼‍♂️<br />
    만약, 관리사무소에서 DR관련 홍보지를 보고 당일 QR코드나 오프라인 신청서를 통해 신청서를 제출하게 된다면,<br />
    수요관리사업자(누리플렉스)가 KPX(전력거래소) 등록기간(매달 15일~20일)에 등록을 진행하게 됩니다.<br />
    등록이 완료되면, 다음달 1일부터 에너지 절감 프로그램에 참여가 가능하게 됩니다.🙅🏼‍♂️</p>,
    category: "register",
  },
  {
    question: "⏸️만약 신청을 취소하고 싶으면 어떤 절차를 거치게 되나요?",
    answer: <p>취소를 원한다면 언제든지 취소가 가능합니다.🙆🏼<br /> 
                이사를 가는 경우에는 자동으로 중단이 되게 됩니다.⏹️</p>,
    category: "register",
  },

  // 운영 및 절차
  {
    question: "💪🏼 신청 및 등록이 완료되면, 어떻게 참여를 진행할 수 있나요?",
    answer: (
      <div style={styles.answerContainer}>
        <p style={styles.text}>
          신청서로 작성된 개인정보를 토대로 전기 절감을 요청하는 알림이 발송되게 되어요!
        </p>
        <img src={KakaoImage} alt="카카오 알림 예시" style={styles.image} />
        <p style={styles.text}>
          알림 발송이 되면 해당 기간 동안의 전기 사용량을 줄이면 되요.
        </p>
      </div>
    ),
    category: "management",
  },
  {
    question: "📅그럼 특정 날짜, 특정 시간대에 줄이면 되는거 아닌가요?",
    answer: <p>발령의 경우 특정 시간, 특정 시간대에 정해놓고 그때 줄이는게 아닙니다!🙅🏼‍♂️<br />
    사람들의 사용량이 많은 오후5~7시경에 집중해서 발령되며, 여름과 겨울철에 더 많이 집중될 수도 있습니다!🚨<br />
    아침이나 저녁시간때에 랜덤으로 발령이 될 수도 있습니다.📢</p>,
    category: "management",
  },
  {
    question: "📢그럼 1년에 어느정도 발령이 되나요?",
    answer: <p>연간 약 70회정도 발령이 될 예정입니다.🚨<br />
    하지만 70회보다 적거나 많을 수도 있습니다!⏰</p>,
    category: "management",
  },

  // 정산 및 보상
  {
    question: "🏦그렇다면 어떠한 방식을 통해 정상금이 계산이 되나요?",
    answer: <p>전기 절감 요청일 이전 10일간의 평균 전기 사용량(*CBL)과 비교하여 절감량을 계산하게 됩니다.</p>,
    category: "reward",
  },
  {
    question: "❔그럼 *CBL이란 무엇인가요?",
    answer: <p>CBL이란 "이 시간에 전기를 얼마나 사용했는지" 보여주는 기준이 되요.🙋🏼‍♂️<br />
                이 기준과 실제 사용량을 비교해 내가 전력을 얼마나 줄였는지 계산하게 되요.🧮</p>,
    category: "reward",
  },
  {
    question: "🙆🏼에너지 절감 프로그램에 참여하여서 에너지 절감에 성공하면 어떤 보상이 주어지나요?",
    answer: <p>1KW/h를 절감하면 약 1,000원이 적립됩니다.💾<br />
                보상금의 경우 절감한 전기량에 따라 달라지게 됩니다.</p>,
    category: "reward",
  },
  {
    question: "⛰️그럼 보상금은 어떤 절차를 통해 주어지게 되나요?",
    answer: <p>국민DR 보상금은 **전력거래소(KPX)**가 먼저 사업자(예: 누리플렉스)에게 지급하고, 사업자가 이를 전력 절감량에 따라 고객(아파트 등)에게 나눠줍니다​.🤳🏼 <br />
     즉, 전력거래소 → 사업자 → 고객 순서로 보상이 이루어집니다! 😊</p>,
    category: "reward",
  },
  {
    question: "🙅🏼‍♂️만약 절감에 실패를 하게 되면 어떻게 되나요?",
    answer: <p>걱정 하지말아요!<br />
                발령 메시지를 받지 못하거나, 해당 감축요청 시간에 외출을 하는등의 이유로 참여를 하지 못하여도 어떠한 패널티는 주어지지 않으니 안심해주세요!🙏🏼</p>,
    category: "reward",
  },

  // 앱 관련
  {
    question: "앱에서 참여 내역을 확인할 수 있나요?",
    answer: "네, 앱의 '내 참여 내역' 탭에서 확인할 수 있습니다.",
    category: "app",
  },

  // 기타 주요 질문
  {
    question: "🏢누리플렉스 회사가 궁금해요",
    answer: (
      <div>
        <p>누리플렉스는 스마트그리드 산업의 선두 기업이에요!</p>
        <ul style={styles.ul}>
          <li style={styles.li}>
            📈 <span>코스닥 상장기업</span>
          </li>
          <li style={styles.li}>
            🪫 <span>AMI(원격 검침 인프라) 국내 최초 개발</span>
          </li>
          <li style={styles.li}>
            📍 <span>AMI 구독, 스마트전력 플랫폼 서비스 제공</span>
          </li>
          <li style={styles.li}>
            🔧 <span>세계 유일 전국규모 AMI 구축 프로젝트 수행</span>
          </li>
          <li style={styles.li}>
            ✅ <span>한전 포함 해외 전력사 49개국이 선택한 기업</span>
          </li>
        </ul>
        <p>
          🏠 <strong>누리플렉스 홈페이지:</strong>{" "}
          <a
            href="http://www.apt-ami.co.kr/nuri/?ckattempt=1"
            target="_blank"
            rel="noopener noreferrer"
          >
            누리플렉스 소개 페이지
          </a>
        </p>
      </div>
    ),
    category: "guitar",
  },
  {
    question: "📜참여신청서를 작성하고 싶어요",
    answer: (
      <div>
        <p>에너지 절약 미션 (시민발전소) 참여 신청서를 작성하고 싶으신가요?</p>
        <p>
          📌 <strong>참여신청서 작성 방법</strong>
          <br />
          1. 아래 참여 신청서 링크 클릭
          <br />
          2. 신청서 작성 (15초 소요)
        </p>
  
        <p>
          <strong>* 현재 신청 가능 단지 🏠</strong>
          <br />
          🏢 래미안 블레스티지 개포
          <br />
          <a href="https://bit.ly/raemianblesstige" target="_blank" rel="noopener noreferrer">
            래미안 블레스티지 신청서
          </a>
          <br />
          <br />
          🏢 위스테이 별내
          <br />
          <a href="https://bit.ly/westay_byeollae" target="_blank" rel="noopener noreferrer">
            위스테이 별내 신청서
          </a>
        </p>
  
        <p>
          점차 운영 단지를 넓혀갈 예정이니, 참여를 희망하는 단지는 1:1 채팅으로 문의해주세요 📟📱
        </p>
      </div>
    ),
    category: "guitar",
  },
  {
    question: `🔌마이에너지가 궁금해요`,
    answer: <p>마이에너지는 전기 요금에 대한 모든 궁금증과 의문점을 해소하는 '전기요금 해결사'에요!🧚🏼‍♂️🧙🏼<br /><br />
    마이에너지는 누리플렉스의 새로운 에너지기반 플랫폼으로써<br />
    DR제도를 활용한 서비스(시민발전소)를 제공하고 있어요.🔌<br /><br />
    전기요금을 모니터링하고 분석할 수 있는 서비스도 출시할 예정이에요.🖥️ </p>,
    category: "guitar",

},
{
  question: "🏠우리 아파트도 참여하고 싶어요",
  answer: (
    <div style={styles.answerContainer}>
      <p style={styles.text}>
        지금은 '래미안블레스티지' 아파트만 시범 운영되고 있어요. 🛠️
      </p>
      <p style={styles.text}>※ 하지만, 운영 단지를 넓혀나갈 예정이에요. 🗺️</p>
      <p style={styles.text}>*참여 중인 단지 (25.02.05 기준)</p>
      
      <ul style={styles.ul}>
        <li style={styles.li}>🏢 개포 래미안 블레스티지</li>
        <li style={styles.li}>🏢 위스테이 별내</li>
      </ul>

      <p style={styles.text}>
        우리 아파트도 참여하고 싶다면 1:1 채팅 상담으로 문의주세요. ☎️
      </p>
    </div>
  ),
  category: "guitar",
},
];

export default faqData;
