import React, { useState } from "react";
import styled from "styled-components";

function TabMenu({ tabs, activeTab, setActiveTab, faqData }) {
  const [openIndex, setOpenIndex] = useState(null);

  const handleQuestionClick = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <Container>
      {/* 탭 메뉴 */}
      <TabContainer>
        {tabs.map((tab) => (
          <TabButton
            key={tab.id}
            active={activeTab === tab.id}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </TabButton>
        ))}
      </TabContainer>

      {/* 질문과 답변 */}
      <FAQContainer>
        {faqData.map((faq, index) => (
          <FAQItem key={index}>
            <Question onClick={() => handleQuestionClick(index)}>
              {faq.question}
              <Icon>{openIndex === index ? "⇧" : "⇩"}</Icon>
            </Question>

            {openIndex === index && <Answer>{faq.answer}</Answer>}
          </FAQItem>
        ))}
      </FAQContainer>
    </Container>
  );
}

export default TabMenu;

/* ✅ 반응형 스타일 적용 */
const Container = styled.div`
  width: 100%;
  max-width: 800px; /* 📌 SearchBar와 같은 크기로 조정 */
  margin: auto;
  padding: 10px;
`;

const TabContainer = styled.div`
  display: flex;
  flex-wrap: wrap; /* 📌 작은 화면에서 줄바꿈 허용 */
  justify-content: center;
  gap: 8px;
  margin-bottom: 20px;
  border-bottom: 2px solid #ddd;

  @media (max-width: 480px) {
    flex-direction: column;
    align-items: center;
  }
`;

const TabButton = styled.button`
  padding: 10px 15px;
  font-size: 14px;
  cursor: pointer;
  background-color: ${(props) => (props.active ? "#007bff" : "#fff")};
  color: ${(props) => (props.active ? "#fff" : "#333")};
  border: none;
  border-bottom: ${(props) =>
    props.active ? "2px solid #007bff" : "2px solid transparent"};
  transition: all 0.3s ease;

  &:hover {
    background: #007bff;
    color: white;
  }

  @media (max-width: 768px) {
    font-size: 12px;
    padding: 8px;
  }

  @media (max-width: 480px) {
    width: 100%;
  }
`;

const FAQContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 100%;
  max-width: 800px; /* 📌 SearchBar와 같은 크기로 조정 */
  margin: auto;
`;

const FAQItem = styled.div`
  background: white;
  border: 1px solid #ddd;
  padding: 10px;
  border-radius: 5px;
  text-align: left;

  @media (max-width: 768px) {
    padding: 8px;
  }
`;

const Question = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: bold;
  cursor: pointer;
  padding: 10px;
  background-color: #f9f9f9;

  @media (max-width: 768px) {
    font-size: 14px;
  }
`;

const Answer = styled.div`
  padding: 10px;
  background-color: #fff;
  border-top: 1px solid #ddd;
  line-height: 1.5;
`;

const Icon = styled.span`
  font-size: 18px;
  color: #007bff;
`;
