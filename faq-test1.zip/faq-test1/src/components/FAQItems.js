import React, { useState } from "react";

function FAQItem({ question, answer }) {
  const [isOpen, setIsOpen] = useState(false); // 답변 열림/닫힘 상태 관리

  const toggleAnswer = () => {
    setIsOpen(!isOpen); // 상태 변경
  };

  return (
    <div style={styles.container}>
      {/* 질문 */}
      <div style={styles.question} onClick={toggleAnswer}>
        <span>{question}</span>
        <span style={styles.icon}>{isOpen ? "-" : "+"}</span>
      </div>

      {/* 답변 (isOpen이 true일 때만 표시) */}
      {isOpen && <div style={styles.answer}>{answer}</div>}
    </div>
  );
}

// 스타일링
const styles = {
  container: {
    border: "1px solid #ddd",
    borderRadius: "10px",
    marginBottom: "10px",
    overflow: "hidden",
  },
  question: {
    padding: "15px",
    cursor: "pointer",
    backgroundColor: "#f9f9f9",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  answer: {
    padding: "15px",
    backgroundColor: "#fff",
    borderTop: "1px solid #ddd",
    textAlign: "left",
  },
  icon: {
    fontSize: "10px",
    fontWeight: "bold",
  },
};

export default FAQItem;
