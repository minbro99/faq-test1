import React, { useState } from "react";
import styled from "styled-components";
import TabMenu from "./components/TabMenu";
import faqData from "./components/FAQData";
import FAQMainLogo from "./styles/logo_1.svg";
import SearchBar from "./components/SearchBar";


function App() {
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  // 필터링된 FAQ 데이터
  const filteredFaqData = faqData.filter((faq) => {
    const isInTab = activeTab === "all" || faq.category === activeTab;

    const searchWords = searchTerm
      .toLowerCase()
      .split(" ")
      .filter((word) => word.trim() !== "");

    const matchesSearch = searchWords.every(
      (word) =>
        faq.question.toLowerCase().includes(word) ||
        (faq.answer && faq.answer.toString().toLowerCase().includes(word))
    );

    return isInTab && matchesSearch;
  });

  const tabs = [
    { id: "all", label: "전체" },
    { id: "basic", label: "기본 개념 및 정의" },
    { id: "register", label: "참여 및 등록" },
    { id: "management", label: "운영 및 절차" },
    { id: "reward", label: "정산 및 보상" },
    { id: "app", label: "앱 관련" },
    { id: "guitar", label: "기타 주요 질문" },
  ];

  return (
    <Container>
      {/* ✅ (로고) 시민발전소 FAQ */}
      <HeaderContainer>
        <Logo src={FAQMainLogo} alt="Logo" />
        <Header>시민발전소 FAQ</Header>
      </HeaderContainer>

      {/* ✅ 검색 바 */}
      <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />

      {/* ✅ 탭 메뉴 및 내용 */}
      <TabMenu
        tabs={tabs}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        faqData={filteredFaqData}
      />
    </Container>
  );
}

/* ✅ 반응형 스타일 적용 */
const Container = styled.div`
  font-family: "Arial", sans-serif;
  padding: 20px;
  max-width: 800px; /* 📌 SearchBar와 TabMenu의 크기와 동일하게 조정 */
  margin: auto;
  text-align: center;

  @media (max-width: 768px) {
    padding: 10px;
  }
`;

const HeaderContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  margin-bottom: 15px;

  @media (max-width: 480px) {
    flex-direction: column; /* 모바일에서는 세로 정렬 */
    text-align: center;
  }
`;

const Logo = styled.img`
  width: 80px;
  height: auto;

  @media (max-width: 480px) {
    width: 50px; /* 작은 화면에서는 로고 크기 조정 */
  }
`;

const Header = styled.h1`
  margin: 0;
  font-size: 40px;
  font-weight: bold;
  color: #333;

  @media (max-width: 768px) {
    font-size: 24px; /* 태블릿에서는 글씨 크기 줄이기 */
  }

  @media (max-width: 480px) {
    font-size: 20px; /* 모바일에서는 더 작게 */
  }
`;

export default App;
